messages = {
    "en": {
        "add_task": "Issue the /add command to create a task.",
    },
    "uz": {
        "add_task": "Vazifa yaratish uchun /add buyrug'ini bering."
    },
    "ru": {
        "add_task": "Введите команду /add, чтобы создать задачу.",
    }

}

result = {
    "en": {
        "res": "you have chosen English"
    },
    "uz": {
        "res": "siz o'zbek tilini tanladingiz"
    },
    "ru": {
        "res": "вы выбрали русский язык"
    }
}